import {bootstrap} from 'angular2/platform/browser';
import * as core from 'angular2/core';

namespace helloWorld {
  @core.Component({
    selector: 'my-app',
    template: `
      <h1>Hello World</h1>
    `,
  })
  export class MyApp { 
  }

}

export function init() {
  bootstrap(helloWorld.MyApp);
}
