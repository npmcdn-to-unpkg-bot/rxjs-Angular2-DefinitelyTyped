﻿class fakeCls {
}