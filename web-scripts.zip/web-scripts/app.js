var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var fakeCls = (function () {
    function fakeCls() {
    }
    return fakeCls;
}());
System.register("libs/utils/flux", ['rxjs/Rx', 'angular2/router'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var rx, router;
    var flux;
    return {
        setters:[
            function (rx_1) {
                rx = rx_1;
            },
            function (router_1) {
                router = router_1;
            }],
        execute: function() {
            (function (flux) {
                function initGlobalState(moduleId, state) {
                    if (flux.globalState[moduleId])
                        throw moduleId + " state already initialized!";
                    state.moduleId = moduleId; //
                    flux.globalState[moduleId] = state;
                    return state;
                }
                flux.initGlobalState = initGlobalState;
                flux.globalState = {};
                function registerModuleDispatcher(moduleId, dispatcher) {
                    if (dispatchers[moduleId])
                        throw moduleId + " dispatcher already exists!";
                    dispatchers[moduleId] = dispatcher;
                }
                flux.registerModuleDispatcher = registerModuleDispatcher;
                var dispatchers = {};
                function callAction(moduleId, actionId, descr, par) {
                    xxxx.next({ moduleId: moduleId, actionId: actionId, par: par, descr: descr });
                }
                flux.callAction = callAction;
                var xxxx = new rx.Subject();
                xxxx.subscribe(function (act) { return callActionDispatcher(act, null); });
                function callActionDispatcher(act, completed) {
                    var disp = dispatchers[act.moduleId];
                    if (!disp)
                        throw act.moduleId + " dispatcher does not exist!";
                    console.log("flux.dispatchAction START: " + act.moduleId + "." + act.descr + "." + (act.par ? JSON.stringify(act.par) : 'null'));
                    disp(flux.globalState[act.moduleId], act.actionId, act.par, function () { console.log("flux.dispatchAction END"); if (completed)
                        completed(); });
                }
                //***************** Play x Record
                var TPlayMode;
                (function (TPlayMode) {
                    TPlayMode[TPlayMode["normal"] = 0] = "normal";
                    TPlayMode[TPlayMode["recording"] = 1] = "recording";
                    TPlayMode[TPlayMode["playing"] = 2] = "playing";
                })(TPlayMode || (TPlayMode = {}));
                var actPlayMode;
                function playActions(actions) {
                    return rx.Observable.fromArray(actions).concatMap(function (act) {
                        return rx.Observable.bindCallback(function (act, callback) {
                            return callActionDispatcher(act, function () { return callback(null); });
                        })(act).concat(rx.Observable.timer(300));
                    } //timeout mezi dvema akcemi
                     //timeout mezi dvema akcemi
                    );
                }
                flux.playActions = playActions;
                var routerLinkCLick = router.RouterLink.prototype.onClick;
                router.RouterLink.prototype.onClick = function () {
                    var pars = this._routeParams;
                    var instr = this._navigationInstruction;
                    //debugger;
                    var url = instr.toRootUrl();
                    return routerLinkCLick.bind(this)();
                };
            })(flux = flux || (flux = {}));
            exports_1("flux", flux);
        }
    }
});
System.register("apps/test-router/testrouter", ['angular2/core', 'angular2/router', "libs/utils/flux"], function(exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var core, router, flux_1;
    var testRouter;
    return {
        setters:[
            function (core_1) {
                core = core_1;
            },
            function (router_2) {
                router = router_2;
            },
            function (flux_1_1) {
                flux_1 = flux_1_1;
            }],
        execute: function() {
            (function (testRouter) {
                var moduleId = 'test-router';
                var TActions;
                (function (TActions) {
                    TActions[TActions["gotoPage1"] = 0] = "gotoPage1";
                    TActions[TActions["gotoPage2"] = 1] = "gotoPage2";
                })(TActions || (TActions = {}));
                function callAction(action, par) {
                    flux_1.flux.callAction(moduleId, action, TActions[action], par);
                }
                var Page1Component = (function () {
                    function Page1Component() {
                    }
                    Page1Component.prototype.gotoPage2 = function () {
                    };
                    Page1Component = __decorate([
                        core.Component({
                            selector: 'page-1',
                            template: '<h1 (click)="gotoPage2()">Page 1</h1>'
                        }), 
                        __metadata('design:paramtypes', [])
                    ], Page1Component);
                    return Page1Component;
                }());
                testRouter.Page1Component = Page1Component;
                var Page2Component = (function () {
                    function Page2Component() {
                    }
                    Page2Component.prototype.gotoPage1 = function () {
                    };
                    Page2Component = __decorate([
                        core.Component({
                            selector: 'page-1',
                            template: '<h1 (click)="gotoPage1()">Page 2</h1>'
                        }),
                        router.CanActivate(function (next, prev) {
                            var data = next.routeData.data;
                            return new Promise(function (res, rej) {
                                setTimeout(function () { return res(true); }, 1000);
                            });
                        }), 
                        __metadata('design:paramtypes', [])
                    ], Page2Component);
                    return Page2Component;
                }());
                testRouter.Page2Component = Page2Component;
                var LMRouterLink = (function (_super) {
                    __extends(LMRouterLink, _super);
                    function LMRouterLink() {
                        _super.apply(this, arguments);
                    }
                    LMRouterLink.prototype.onClick = function () { return _super.prototype.onClick.call(this); };
                    return LMRouterLink;
                }(router.RouterLink));
                testRouter.LMRouterLink = LMRouterLink;
                var MyApp = (function () {
                    function MyApp() {
                    }
                    MyApp = __decorate([
                        core.Component({
                            selector: 'my-app',
                            template: "\n      <a [routerLink]=\"['Page1', {a:0, b:1}]\">Page 1</a>\n      <a [routerLink]=\"['Page2']\">Page 2</a>\n      <hr/>\n      <router-outlet></router-outlet>\n    ",
                            directives: [router.ROUTER_DIRECTIVES]
                        }),
                        router.RouteConfig([
                            { path: '/page-1', name: 'Page1', component: Page1Component, useAsDefault: true },
                            { path: '/page-2', name: 'Page2', component: Page2Component }
                        ]), 
                        __metadata('design:paramtypes', [])
                    ], MyApp);
                    return MyApp;
                }());
                testRouter.MyApp = MyApp;
                flux_1.flux.registerModuleDispatcher(moduleId, function (moduleState, actionId, actionPar, callback) {
                    switch (actionId) {
                        case TActions.gotoPage1:
                            callback();
                            return;
                        case TActions.gotoPage2:
                            callback();
                            return;
                    }
                });
                var state = flux_1.flux.initGlobalState(moduleId, {});
            })(testRouter = testRouter || (testRouter = {}));
            exports_2("testRouter", testRouter);
        }
    }
});
System.register("apps/test-router/main", ['angular2/platform/browser', 'angular2/core', 'angular2/router', "apps/test-router/testrouter"], function(exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var browser_1, core, router, testrouter_1;
    function init() {
        browser_1.bootstrap(testrouter_1.testRouter.MyApp, [router.ROUTER_PROVIDERS, core.provide(router.LocationStrategy, { useClass: router.HashLocationStrategy })])
            .then(function (appRef) {
            var inj = appRef.injector;
            var r = inj.get(router.Router);
        })
            .catch(function (err) { return '*** ERROR in main.bootstrap: ' + console.error(err); });
    }
    exports_3("init", init);
    return {
        setters:[
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (core_2) {
                core = core_2;
            },
            function (router_3) {
                router = router_3;
            },
            function (testrouter_1_1) {
                testrouter_1 = testrouter_1_1;
            }],
        execute: function() {
        }
    }
});
System.register("apps/hello-world/main", ['angular2/platform/browser', 'angular2/core'], function(exports_4, context_4) {
    "use strict";
    var __moduleName = context_4 && context_4.id;
    var browser_2, core;
    var helloWorld;
    function init() {
        browser_2.bootstrap(helloWorld.MyApp);
    }
    exports_4("init", init);
    return {
        setters:[
            function (browser_2_1) {
                browser_2 = browser_2_1;
            },
            function (core_3) {
                core = core_3;
            }],
        execute: function() {
            (function (helloWorld) {
                var MyApp = (function () {
                    function MyApp() {
                    }
                    MyApp = __decorate([
                        core.Component({
                            selector: 'my-app',
                            template: "\n      <h1>Hello World</h1>\n    ",
                        }), 
                        __metadata('design:paramtypes', [])
                    ], MyApp);
                    return MyApp;
                }());
                helloWorld.MyApp = MyApp;
            })(helloWorld || (helloWorld = {}));
        }
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmFrZUNscy50cyIsImxpYnMvdXRpbHMvZmx1eC50cyIsImFwcHMvdGVzdC1yb3V0ZXIvdGVzdHJvdXRlci50cyIsImFwcHMvdGVzdC1yb3V0ZXIvbWFpbi50cyIsImFwcHMvaGVsbG8td29ybGQvbWFpbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFDO0lBQUE7SUFDRCxDQUFDO0lBQUQsY0FBQztBQUFELENBQUMsQUFEQSxJQUNBOzs7Ozs7Ozs7Ozs7Ozs7WUNHRCxXQUFpQixJQUFJLEVBQUMsQ0FBQztnQkFLckIseUJBQXdELFFBQWdCLEVBQUUsS0FBUTtvQkFDaEYsRUFBRSxDQUFDLENBQUMsZ0JBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFBQyxNQUFTLFFBQVEsZ0NBQTZCLENBQUM7b0JBQzFFLEtBQUssQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFBRTtvQkFDN0IsZ0JBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUM7b0JBQzlCLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQ2YsQ0FBQztnQkFMZSxvQkFBZSxrQkFLOUIsQ0FBQTtnQkFHWSxnQkFBVyxHQUFpQixFQUFFLENBQUM7Z0JBZTVDLGtDQUE0QyxRQUFnQixFQUFFLFVBQStCO29CQUMzRixFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQUMsTUFBUyxRQUFRLGdDQUE2QixDQUFDO29CQUMxRSxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsVUFBVSxDQUFDO2dCQUNyQyxDQUFDO2dCQUhlLDZCQUF3QiwyQkFHdkMsQ0FBQTtnQkFBQyxJQUFJLFdBQVcsR0FBbUQsRUFBRSxDQUFDO2dCQUV2RSxvQkFBaUQsUUFBZ0IsRUFBRSxRQUFnQixFQUFFLEtBQWEsRUFBRSxHQUFNO29CQUN4RyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7Z0JBQ2hGLENBQUM7Z0JBRmUsZUFBVSxhQUV6QixDQUFBO2dCQUVELElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBdUIsQ0FBQztnQkFFakQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLG9CQUFvQixDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsRUFBL0IsQ0FBK0IsQ0FBQyxDQUFDO2dCQUV2RCw4QkFBOEIsR0FBWSxFQUFFLFNBQW9CO29CQUM5RCxJQUFJLElBQUksR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNyQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFBQyxNQUFTLEdBQUcsQ0FBQyxRQUFRLGdDQUE2QixDQUFDO29CQUM5RCxPQUFPLENBQUMsR0FBRyxDQUFDLGdDQUE4QixHQUFHLENBQUMsUUFBUSxTQUFJLEdBQUcsQ0FBQyxLQUFLLFVBQUksR0FBRyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUUsQ0FBQyxDQUFDO29CQUNySCxJQUFJLENBQUMsZ0JBQVcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLGNBQVEsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO3dCQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hJLENBQUM7Z0JBRUQsaUNBQWlDO2dCQUNqQyxJQUFLLFNBQXdDO2dCQUE3QyxXQUFLLFNBQVM7b0JBQUcsNkNBQU0sQ0FBQTtvQkFBRSxtREFBUyxDQUFBO29CQUFFLCtDQUFPLENBQUE7Z0JBQUMsQ0FBQyxFQUF4QyxTQUFTLEtBQVQsU0FBUyxRQUErQjtnQkFDN0MsSUFBSSxXQUFzQixDQUFDO2dCQUUzQixxQkFBNEIsT0FBdUI7b0JBQ2pELE1BQU0sQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxHQUFHO3dCQUNuRCxPQUFBLEVBQUUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFlLFVBQUMsR0FBRyxFQUFFLFFBQVE7NEJBQ3JELE9BQUEsb0JBQW9CLENBQUMsR0FBRyxFQUFFLGNBQU0sT0FBQSxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQWQsQ0FBYyxDQUFDO3dCQUEvQyxDQUErQyxDQUNoRCxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFGdkMsQ0FFdUMsQ0FBQywyQkFBMkI7b0JBQTVCLENBQUMsMkJBQTJCO3FCQUNwRSxDQUFDO2dCQUNKLENBQUM7Z0JBTmUsZ0JBQVcsY0FNMUIsQ0FBQTtnQkFFRCxJQUFJLGVBQWUsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7Z0JBQzFELE1BQU0sQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRztvQkFDcEMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztvQkFDN0IsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDO29CQUN4QyxXQUFXO29CQUNYLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDNUIsTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztnQkFDdEMsQ0FBQyxDQUFBO1lBRUgsQ0FBQyxFQXJFZ0IsSUFBSSxHQUFKLElBQUksS0FBSixJQUFJLFFBcUVwQjtvQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lDbkVELFdBQWlCLFVBQVUsRUFBQyxDQUFDO2dCQUUzQixJQUFNLFFBQVEsR0FBRyxhQUFhLENBQUM7Z0JBQy9CLElBQUssUUFBaUM7Z0JBQXRDLFdBQUssUUFBUTtvQkFBRyxpREFBUyxDQUFBO29CQUFFLGlEQUFTLENBQUE7Z0JBQUMsQ0FBQyxFQUFqQyxRQUFRLEtBQVIsUUFBUSxRQUF5QjtnQkFDdEMsb0JBQStDLE1BQWdCLEVBQUUsR0FBTTtvQkFDckUsV0FBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDM0QsQ0FBQztnQkFNRDtvQkFDRTtvQkFDQSxDQUFDO29CQUNELGtDQUFTLEdBQVQ7b0JBQ0EsQ0FBQztvQkFSSDt3QkFBQyxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNkLFFBQVEsRUFBRSxRQUFROzRCQUNsQixRQUFRLEVBQUUsdUNBQXVDO3lCQUNsRCxDQUFDOztzQ0FBQTtvQkFNRixxQkFBQztnQkFBRCxDQUFDLEFBTEQsSUFLQztnQkFMWSx5QkFBYyxpQkFLMUIsQ0FBQTtnQkFZRDtvQkFDRTtvQkFDQSxDQUFDO29CQUNELGtDQUFTLEdBQVQ7b0JBQ0EsQ0FBQztvQkFkSDt3QkFBQyxJQUFJLENBQUMsU0FBUyxDQUFDOzRCQUNkLFFBQVEsRUFBRSxRQUFROzRCQUNsQixRQUFRLEVBQUUsdUNBQXVDO3lCQUNsRCxDQUFDO3dCQUNELE1BQU0sQ0FBQyxXQUFXLENBQUMsVUFBQyxJQUFpQyxFQUFFLElBQWlDOzRCQUN2RixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQzs0QkFDL0IsTUFBTSxDQUFDLElBQUksT0FBTyxDQUFDLFVBQUMsR0FBRyxFQUFFLEdBQUc7Z0NBQzFCLFVBQVUsQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFULENBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQzs0QkFDcEMsQ0FBQyxDQUFDLENBQUE7d0JBQ0osQ0FBQyxDQUFDOztzQ0FBQTtvQkFNRixxQkFBQztnQkFBRCxDQUFDLEFBTEQsSUFLQztnQkFMWSx5QkFBYyxpQkFLMUIsQ0FBQTtnQkFFRDtvQkFBa0MsZ0NBQWlCO29CQUFuRDt3QkFBa0MsOEJBQWlCO29CQUVuRCxDQUFDO29CQURDLDhCQUFPLEdBQVAsY0FBcUIsTUFBTSxDQUFDLGdCQUFLLENBQUMsT0FBTyxXQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNoRCxtQkFBQztnQkFBRCxDQUFDLEFBRkQsQ0FBa0MsTUFBTSxDQUFDLFVBQVUsR0FFbEQ7Z0JBRlksdUJBQVksZUFFeEIsQ0FBQTtnQkFnQkQ7b0JBQ0U7b0JBQ0EsQ0FBQztvQkFoQkg7d0JBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzs0QkFDZCxRQUFRLEVBQUUsUUFBUTs0QkFDbEIsUUFBUSxFQUFFLHdLQUtUOzRCQUNELFVBQVUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQzt5QkFDdkMsQ0FBQzt3QkFDRCxNQUFNLENBQUMsV0FBVyxDQUFDOzRCQUNsQixFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUU7NEJBQ2pGLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUU7eUJBQzlELENBQUM7OzZCQUFBO29CQUlGLFlBQUM7Z0JBQUQsQ0FBQyxBQUhELElBR0M7Z0JBSFksZ0JBQUssUUFHakIsQ0FBQTtnQkFTRCxXQUFJLENBQUMsd0JBQXdCLENBQVMsUUFBUSxFQUFFLFVBQUMsV0FBbUIsRUFBRSxRQUFrQixFQUFFLFNBQTBCLEVBQUUsUUFBd0I7b0JBQzVJLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7d0JBQ2pCLEtBQUssUUFBUSxDQUFDLFNBQVM7NEJBQ3JCLFFBQVEsRUFBRSxDQUFDOzRCQUNYLE1BQU0sQ0FBQzt3QkFDVCxLQUFLLFFBQVEsQ0FBQyxTQUFTOzRCQUNyQixRQUFRLEVBQUUsQ0FBQzs0QkFDWCxNQUFNLENBQUM7b0JBQ1gsQ0FBQztnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFNLEtBQUssR0FBRyxXQUFJLENBQUMsZUFBZSxDQUFTLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUUzRCxDQUFDLEVBL0VnQixVQUFVLEdBQVYsVUFBVSxLQUFWLFVBQVUsUUErRTFCO2dEQUFBOzs7Ozs7OztJQy9FRDtRQUNFLG1CQUFTLENBQUMsdUJBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxRQUFRLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ3JJLElBQUksQ0FBQyxVQUFBLE1BQU07WUFDVixJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQzFCLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLCtCQUErQixHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQXBELENBQW9ELENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBUEQsdUJBT0MsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDRUQ7UUFDRSxtQkFBUyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBRkQsdUJBRUMsQ0FBQTs7Ozs7Ozs7OztZQWRELFdBQVUsVUFBVSxFQUFDLENBQUM7Z0JBT3BCO29CQUFBO29CQUNBLENBQUM7b0JBUEQ7d0JBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzs0QkFDZCxRQUFRLEVBQUUsUUFBUTs0QkFDbEIsUUFBUSxFQUFFLG9DQUVUO3lCQUNGLENBQUM7OzZCQUFBO29CQUVGLFlBQUM7Z0JBQUQsQ0FBQyxBQURELElBQ0M7Z0JBRFksZ0JBQUssUUFDakIsQ0FBQTtZQUVILENBQUMsRUFWUyxVQUFVLEtBQVYsVUFBVSxRQVVuQiIsInNvdXJjZXNDb250ZW50IjpbIu+7v2NsYXNzIGZha2VDbHMge1xyXG59Iiwi77u/aW1wb3J0ICogYXMgcnggZnJvbSAncnhqcy9SeCc7XHJcbmltcG9ydCAqIGFzIGNvcmUgZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcbmltcG9ydCAqIGFzIHJvdXRlciBmcm9tICdhbmd1bGFyMi9yb3V0ZXInO1xyXG5cclxuZXhwb3J0IG5hbWVzcGFjZSBmbHV4IHtcclxuXHJcbiAgLy8qKioqKioqKioqKioqKiogR0xPQkFMICYgTU9EVUxFIEFQUCBTVEFURVxyXG4gIGV4cG9ydCBpbnRlcmZhY2UgSU1vZHVsZVN0YXRlIHsgbW9kdWxlSWQ/OiBzdHJpbmcgfSAvL2dsb2JhbG5pIHN0YXYgbW9kdWx1XHJcblxyXG4gIGV4cG9ydCBmdW5jdGlvbiBpbml0R2xvYmFsU3RhdGU8VCBleHRlbmRzIElNb2R1bGVTdGF0ZT4obW9kdWxlSWQ6IHN0cmluZywgc3RhdGU6IFQpOiBUIHsgLy9pbmljaWFsaXphY2UgZ2xvYmFsbmlobyBzdGF2dSBtb2R1bHVcclxuICAgIGlmIChnbG9iYWxTdGF0ZVttb2R1bGVJZF0pIHRocm93IGAke21vZHVsZUlkfSBzdGF0ZSBhbHJlYWR5IGluaXRpYWxpemVkIWA7XHJcbiAgICBzdGF0ZS5tb2R1bGVJZCA9IG1vZHVsZUlkOyAvL1xyXG4gICAgZ2xvYmFsU3RhdGVbbW9kdWxlSWRdID0gc3RhdGU7XHJcbiAgICByZXR1cm4gc3RhdGU7XHJcbiAgfVxyXG5cclxuICBleHBvcnQgdHlwZSBUR2xvYmFsU3RhdGUgPSB7IFttb2R1bGVJZDogc3RyaW5nXTogSU1vZHVsZVN0YXRlOyB9OyAvL3R5cCBnbG9iYWxuaWhvIHN0YXYgYXBsaWthY2VcclxuICBleHBvcnQgY29uc3QgZ2xvYmFsU3RhdGU6IFRHbG9iYWxTdGF0ZSA9IHt9O1xyXG5cclxuICAvLyoqKioqKioqKioqKioqKiBBQ1RJT04gRElTUEFUQ0hcclxuICBleHBvcnQgaW50ZXJmYWNlIElBY3Rpb248VCBleHRlbmRzIElBY3Rpb25QYXI+IHsgLy9mbHV4IGFjdGlvblxyXG4gICAgbW9kdWxlSWQ6IHN0cmluZztcclxuICAgIGFjdGlvbklkOiBudW1iZXI7XHJcbiAgICBkZXNjcjogc3RyaW5nO1xyXG4gICAgcGFyOiBUO1xyXG4gIH1cclxuICBleHBvcnQgaW50ZXJmYWNlIElBY3Rpb25QYXIgeyB9IC8vZmx1eCBhY3Rpb24gcGFyXHJcbiAgZXhwb3J0IHR5cGUgVEFjdGlvbiA9IElBY3Rpb248SUFjdGlvblBhcj47XHJcblxyXG4gIGV4cG9ydCB0eXBlIG1vZHVsZURpc3BhdGNoZXI8VCBleHRlbmRzIElNb2R1bGVTdGF0ZT4gPSAobW9kdWxlU3RhdGU6IFQsIGFjdGlvbklkOiBudW1iZXIsIHBhcjogSUFjdGlvblBhciwgY2FsbGJhY2s6IFRDYWxsYmFjaykgPT4gdm9pZDsgLy9hY3Rpb24gZGlzcGF0Y2hlciBmdW5jdGlvbiB0eXBlXHJcbiAgZXhwb3J0IHR5cGUgVENhbGxiYWNrID0gKCkgPT4gdm9pZDtcclxuXHJcbiAgZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyTW9kdWxlRGlzcGF0Y2hlcjxUPihtb2R1bGVJZDogc3RyaW5nLCBkaXNwYXRjaGVyOiBtb2R1bGVEaXNwYXRjaGVyPFQ+KSB7IC8vcmVnaXN0ZXIgYWN0aW9uIGRpc3BhdGNoZXIgZnVuY3Rpb25cclxuICAgIGlmIChkaXNwYXRjaGVyc1ttb2R1bGVJZF0pIHRocm93IGAke21vZHVsZUlkfSBkaXNwYXRjaGVyIGFscmVhZHkgZXhpc3RzIWA7XHJcbiAgICBkaXNwYXRjaGVyc1ttb2R1bGVJZF0gPSBkaXNwYXRjaGVyO1xyXG4gIH0gdmFyIGRpc3BhdGNoZXJzOiB7IFttb2R1bGVJZDogc3RyaW5nXTogbW9kdWxlRGlzcGF0Y2hlcjxhbnk+OyB9ID0ge307XHJcblxyXG4gIGV4cG9ydCBmdW5jdGlvbiBjYWxsQWN0aW9uPFQgZXh0ZW5kcyBJQWN0aW9uUGFyPihtb2R1bGVJZDogc3RyaW5nLCBhY3Rpb25JZDogbnVtYmVyLCBkZXNjcjogc3RyaW5nLCBwYXI6IFQpIHsgLy9jYWxsIGFjdGlvblxyXG4gICAgeHh4eC5uZXh0KHsgbW9kdWxlSWQ6IG1vZHVsZUlkLCBhY3Rpb25JZDogYWN0aW9uSWQsIHBhcjogcGFyLCBkZXNjcjogZGVzY3IgfSk7XHJcbiAgfVxyXG5cclxuICB2YXIgeHh4eCA9IG5ldyByeC5TdWJqZWN0PElBY3Rpb248SUFjdGlvblBhcj4+KCk7XHJcblxyXG4gIHh4eHguc3Vic2NyaWJlKGFjdCA9PiBjYWxsQWN0aW9uRGlzcGF0Y2hlcihhY3QsIG51bGwpKTtcclxuXHJcbiAgZnVuY3Rpb24gY2FsbEFjdGlvbkRpc3BhdGNoZXIoYWN0OiBUQWN0aW9uLCBjb21wbGV0ZWQ6IFRDYWxsYmFjaykge1xyXG4gICAgdmFyIGRpc3AgPSBkaXNwYXRjaGVyc1thY3QubW9kdWxlSWRdO1xyXG4gICAgaWYgKCFkaXNwKSB0aHJvdyBgJHthY3QubW9kdWxlSWR9IGRpc3BhdGNoZXIgZG9lcyBub3QgZXhpc3QhYDtcclxuICAgIGNvbnNvbGUubG9nKGBmbHV4LmRpc3BhdGNoQWN0aW9uIFNUQVJUOiAke2FjdC5tb2R1bGVJZH0uJHthY3QuZGVzY3J9LiR7YWN0LnBhciA/IEpTT04uc3RyaW5naWZ5KGFjdC5wYXIpIDogJ251bGwnfWApO1xyXG4gICAgZGlzcChnbG9iYWxTdGF0ZVthY3QubW9kdWxlSWRdLCBhY3QuYWN0aW9uSWQsIGFjdC5wYXIsICgpID0+IHsgY29uc29sZS5sb2coYGZsdXguZGlzcGF0Y2hBY3Rpb24gRU5EYCk7IGlmIChjb21wbGV0ZWQpIGNvbXBsZXRlZCgpOyB9KTtcclxuICB9XHJcblxyXG4gIC8vKioqKioqKioqKioqKioqKiogUGxheSB4IFJlY29yZFxyXG4gIGVudW0gVFBsYXlNb2RlIHsgbm9ybWFsLCByZWNvcmRpbmcsIHBsYXlpbmcgfVxyXG4gIHZhciBhY3RQbGF5TW9kZTogVFBsYXlNb2RlO1xyXG5cclxuICBleHBvcnQgZnVuY3Rpb24gcGxheUFjdGlvbnMoYWN0aW9uczogQXJyYXk8VEFjdGlvbj4pOiByeC5PYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuIHJ4Lk9ic2VydmFibGUuZnJvbUFycmF5KGFjdGlvbnMpLmNvbmNhdE1hcChhY3QgPT5cclxuICAgICAgcnguT2JzZXJ2YWJsZS5iaW5kQ2FsbGJhY2s8VEFjdGlvbiwgYW55PigoYWN0LCBjYWxsYmFjaykgPT4gLy9PYnNlcnZhYmxlIHogQ2FsbGJhY2stZWQgYWN0aW9uXHJcbiAgICAgICAgY2FsbEFjdGlvbkRpc3BhdGNoZXIoYWN0LCAoKSA9PiBjYWxsYmFjayhudWxsKSlcclxuICAgICAgKShhY3QpLmNvbmNhdChyeC5PYnNlcnZhYmxlLnRpbWVyKDMwMCkpIC8vdGltZW91dCBtZXppIGR2ZW1hIGFrY2VtaVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHZhciByb3V0ZXJMaW5rQ0xpY2sgPSByb3V0ZXIuUm91dGVyTGluay5wcm90b3R5cGUub25DbGljaztcclxuICByb3V0ZXIuUm91dGVyTGluay5wcm90b3R5cGUub25DbGljayA9IGZ1bmN0aW9uICgpIHtcclxuICAgIHZhciBwYXJzID0gdGhpcy5fcm91dGVQYXJhbXM7XHJcbiAgICB2YXIgaW5zdHIgPSB0aGlzLl9uYXZpZ2F0aW9uSW5zdHJ1Y3Rpb247XHJcbiAgICAvL2RlYnVnZ2VyO1xyXG4gICAgdmFyIHVybCA9IGluc3RyLnRvUm9vdFVybCgpO1xyXG4gICAgcmV0dXJuIHJvdXRlckxpbmtDTGljay5iaW5kKHRoaXMpKCk7XHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQgKiBhcyBjb3JlIGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xyXG5pbXBvcnQgKiBhcyByb3V0ZXIgZnJvbSAnYW5ndWxhcjIvcm91dGVyJztcclxuaW1wb3J0IHtmbHV4fSBmcm9tICcuLi8uLi9saWJzL3V0aWxzL2ZsdXgnO1xyXG5pbXBvcnQgKiBhcyByeCBmcm9tICdyeGpzL1J4JztcclxuaW1wb3J0ICogYXMgaHR0cCBmcm9tICdhbmd1bGFyMi9odHRwJztcclxuXHJcbmV4cG9ydCBuYW1lc3BhY2UgdGVzdFJvdXRlciB7XHJcblxyXG4gIGNvbnN0IG1vZHVsZUlkID0gJ3Rlc3Qtcm91dGVyJztcclxuICBlbnVtIFRBY3Rpb25zIHsgZ290b1BhZ2UxLCBnb3RvUGFnZTIgfVxyXG4gIGZ1bmN0aW9uIGNhbGxBY3Rpb248VCBleHRlbmRzIGZsdXguSUFjdGlvblBhcj4oYWN0aW9uOiBUQWN0aW9ucywgcGFyOiBUKSB7XHJcbiAgICBmbHV4LmNhbGxBY3Rpb24obW9kdWxlSWQsIGFjdGlvbiwgVEFjdGlvbnNbYWN0aW9uXSwgcGFyKTtcclxuICB9XHJcblxyXG4gIEBjb3JlLkNvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ3BhZ2UtMScsXHJcbiAgICB0ZW1wbGF0ZTogJzxoMSAoY2xpY2spPVwiZ290b1BhZ2UyKClcIj5QYWdlIDE8L2gxPidcclxuICB9KVxyXG4gIGV4cG9ydCBjbGFzcyBQYWdlMUNvbXBvbmVudCB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIH1cclxuICAgIGdvdG9QYWdlMigpIHtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIEBjb3JlLkNvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ3BhZ2UtMScsXHJcbiAgICB0ZW1wbGF0ZTogJzxoMSAoY2xpY2spPVwiZ290b1BhZ2UxKClcIj5QYWdlIDI8L2gxPidcclxuICB9KVxyXG4gIEByb3V0ZXIuQ2FuQWN0aXZhdGUoKG5leHQ6IHJvdXRlci5Db21wb25lbnRJbnN0cnVjdGlvbiwgcHJldjogcm91dGVyLkNvbXBvbmVudEluc3RydWN0aW9uKSA9PiB7XHJcbiAgICB2YXIgZGF0YSA9IG5leHQucm91dGVEYXRhLmRhdGE7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlcywgcmVqKSA9PiB7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gcmVzKHRydWUpLCAxMDAwKTtcclxuICAgIH0pXHJcbiAgfSlcclxuICBleHBvcnQgY2xhc3MgUGFnZTJDb21wb25lbnQge1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB9XHJcbiAgICBnb3RvUGFnZTEoKSB7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBleHBvcnQgY2xhc3MgTE1Sb3V0ZXJMaW5rIGV4dGVuZHMgcm91dGVyLlJvdXRlckxpbmsge1xyXG4gICAgb25DbGljaygpOiBib29sZWFuIHsgcmV0dXJuIHN1cGVyLm9uQ2xpY2soKTsgfVxyXG4gIH1cclxuXHJcbiAgQGNvcmUuQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnbXktYXBwJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgIDxhIFtyb3V0ZXJMaW5rXT1cIlsnUGFnZTEnLCB7YTowLCBiOjF9XVwiPlBhZ2UgMTwvYT5cclxuICAgICAgPGEgW3JvdXRlckxpbmtdPVwiWydQYWdlMiddXCI+UGFnZSAyPC9hPlxyXG4gICAgICA8aHIvPlxyXG4gICAgICA8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+XHJcbiAgICBgLFxyXG4gICAgZGlyZWN0aXZlczogW3JvdXRlci5ST1VURVJfRElSRUNUSVZFU11cclxuICB9KVxyXG4gIEByb3V0ZXIuUm91dGVDb25maWcoW1xyXG4gICAgeyBwYXRoOiAnL3BhZ2UtMScsIG5hbWU6ICdQYWdlMScsIGNvbXBvbmVudDogUGFnZTFDb21wb25lbnQsIHVzZUFzRGVmYXVsdDogdHJ1ZSB9LFxyXG4gICAgeyBwYXRoOiAnL3BhZ2UtMicsIG5hbWU6ICdQYWdlMicsIGNvbXBvbmVudDogUGFnZTJDb21wb25lbnQgfVxyXG4gIF0pXHJcbiAgZXhwb3J0IGNsYXNzIE15QXBwIHsgLy9leHRlbmRzIHJvdXRlci5PblJldXNlIHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZXhwb3J0IGludGVyZmFjZSBJU3RhdGUgZXh0ZW5kcyBmbHV4LklNb2R1bGVTdGF0ZSB7XHJcbiAgfVxyXG5cclxuICBpbnRlcmZhY2UgSUNsaWNrQWN0aW9uUGFyIGV4dGVuZHMgZmx1eC5JQWN0aW9uUGFyIHtcclxuICB9XHJcblxyXG5cclxuICBmbHV4LnJlZ2lzdGVyTW9kdWxlRGlzcGF0Y2hlcjxJU3RhdGU+KG1vZHVsZUlkLCAobW9kdWxlU3RhdGU6IElTdGF0ZSwgYWN0aW9uSWQ6IFRBY3Rpb25zLCBhY3Rpb25QYXI6IGZsdXguSUFjdGlvblBhciwgY2FsbGJhY2s6IGZsdXguVENhbGxiYWNrKSA9PiB7XHJcbiAgICBzd2l0Y2ggKGFjdGlvbklkKSB7XHJcbiAgICAgIGNhc2UgVEFjdGlvbnMuZ290b1BhZ2UxOlxyXG4gICAgICAgIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICBjYXNlIFRBY3Rpb25zLmdvdG9QYWdlMjpcclxuICAgICAgICBjYWxsYmFjaygpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc3RhdGUgPSBmbHV4LmluaXRHbG9iYWxTdGF0ZTxJU3RhdGU+KG1vZHVsZUlkLCB7fSk7XHJcblxyXG59IiwiaW1wb3J0IHtib290c3RyYXB9IGZyb20gJ2FuZ3VsYXIyL3BsYXRmb3JtL2Jyb3dzZXInO1xyXG5pbXBvcnQgKiBhcyBjb3JlIGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xyXG5pbXBvcnQgKiBhcyByb3V0ZXIgZnJvbSAnYW5ndWxhcjIvcm91dGVyJ1xyXG5pbXBvcnQge3Rlc3RSb3V0ZXJ9IGZyb20gJy4vdGVzdHJvdXRlcidcclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW5pdCgpIHtcclxuICBib290c3RyYXAodGVzdFJvdXRlci5NeUFwcCwgW3JvdXRlci5ST1VURVJfUFJPVklERVJTLCBjb3JlLnByb3ZpZGUocm91dGVyLkxvY2F0aW9uU3RyYXRlZ3ksIHsgdXNlQ2xhc3M6IHJvdXRlci5IYXNoTG9jYXRpb25TdHJhdGVneSB9KV0pXHJcbiAgICAudGhlbihhcHBSZWYgPT4ge1xyXG4gICAgICB2YXIgaW5qID0gYXBwUmVmLmluamVjdG9yO1xyXG4gICAgICB2YXIgciA9IGluai5nZXQocm91dGVyLlJvdXRlcik7XHJcbiAgICB9KVxyXG4gICAgLmNhdGNoKGVyciA9PiAnKioqIEVSUk9SIGluIG1haW4uYm9vdHN0cmFwOiAnICsgY29uc29sZS5lcnJvcihlcnIpKTsgICAgICBcclxufVxyXG4iLCJpbXBvcnQge2Jvb3RzdHJhcH0gZnJvbSAnYW5ndWxhcjIvcGxhdGZvcm0vYnJvd3Nlcic7XHJcbmltcG9ydCAqIGFzIGNvcmUgZnJvbSAnYW5ndWxhcjIvY29yZSc7XHJcblxyXG5uYW1lc3BhY2UgaGVsbG9Xb3JsZCB7XHJcbiAgQGNvcmUuQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnbXktYXBwJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgIDxoMT5IZWxsbyBXb3JsZDwvaDE+XHJcbiAgICBgLFxyXG4gIH0pXHJcbiAgZXhwb3J0IGNsYXNzIE15QXBwIHsgXHJcbiAgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGluaXQoKSB7XHJcbiAgYm9vdHN0cmFwKGhlbGxvV29ybGQuTXlBcHApO1xyXG59XHJcbiJdfQ==