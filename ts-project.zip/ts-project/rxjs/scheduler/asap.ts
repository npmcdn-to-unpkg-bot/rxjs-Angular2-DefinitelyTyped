import {AsapScheduler} from './AsapScheduler';

export const asap = new AsapScheduler();