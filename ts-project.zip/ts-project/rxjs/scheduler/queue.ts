import {QueueScheduler} from './QueueScheduler';

export const queue = new QueueScheduler();