import {AsyncScheduler} from './AsyncScheduler';

export const async = new AsyncScheduler();
