import {global} from 'angular2/src/facade/lang';

export var Math = global.Math;
export var NaN = typeof NaN;
