// Public API for Zone
export {NgZone, ZeroArgFunction, ErrorHandlingFn, NgZoneError} from './zone/ng_zone';
