/**
 * This is here because DART requires it. It is noop in JS.
 */
export function wtfInit() {}
